
package Login;

import Logica.EncargoDAO;
import Logica.EncargoJosephDAO;
import Logica.EncargoNicolasDAO;
import Login.Login1;
import SourceAdmin.ConsultarEncargosAdmin;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import SourceCliente.MisDatosInterfaz;


public class InterfazAdmin extends javax.swing.JFrame {

    EncargoDAO encargoDAO;
    FondoPanel fondo = new FondoPanel();
    Login1 login1;
    EncargoNicolasDAO encargoNicolasDAO;
    EncargoJosephDAO encargoJosephDAO;
    SourceAdmin.MisDatosInterfaz misDatosInterfaz;
    InterfazCliente interfazCliente;
    InterfazCliente2 interfazCliente2;
    //ConsultarEncargosAdmin consultarEncargosAdmin;
    String respuestaChat = null;
    boolean boolChatRespuesta = false;
    public InterfazCliente boolChat;
    private InterfazCliente solicitudChat;
    String respuestaChat2 = null;
    boolean boolChatRespuesta2 = false;
    public InterfazCliente2 boolChat2;
    private InterfazCliente solicitudChat2;
    
    public InterfazAdmin(Login1 login1, EncargoDAO EncargoDAO, EncargoJosephDAO EncargoJosephDAO, EncargoNicolasDAO EncargoNicolasDAO) {
        this.encargoDAO=EncargoDAO;
        this.encargoJosephDAO=EncargoJosephDAO;
        this.encargoNicolasDAO=EncargoNicolasDAO;
        this.setContentPane(fondo);
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        this.login1 = login1;
        misDatosInterfaz = new SourceAdmin.MisDatosInterfaz();
        

    }
    public FondoPanel getFondo() {
        return fondo;
    }
    
    public void setFondo(FondoPanel fondo) {
        this.fondo = fondo;
    }

    public Login1 getLogin1() {
        return login1;
    }

    public void setLogin1(Login1 login1) {
        this.login1 = login1;
    }

    public InterfazCliente getInterfazCliente() {
        return interfazCliente;
    }

    public void setInterfazCliente(InterfazCliente interfazCliente) {
        this.interfazCliente = interfazCliente;
      
    }
    public void setInterfazCliente2(InterfazCliente2 interfazCliente2) {
    
        this.interfazCliente2 = interfazCliente2;
    }
    

    public InterfazCliente getBoolChat() {
        return boolChat;
    }

    public void setBoolChat(InterfazCliente boolChat) {
        this.boolChat = boolChat;
    }

    public InterfazCliente getSolicitudChat() {
        return solicitudChat;
    }

    public void setSolicitudChat(InterfazCliente solicitudChat) {
        this.solicitudChat = solicitudChat;
    }

    public JLabel getENTRAR() {
        return ENTRAR;
    }

    public void setENTRAR(JLabel ENTRAR) {
        this.ENTRAR = ENTRAR;
    }

    public JLabel getENTRAR1() {
        return ENTRAR1;
    }

    public void setENTRAR1(JLabel ENTRAR1) {
        this.ENTRAR1 = ENTRAR1;
    }

    public JLabel getENTRAR2() {
        return ENTRAR2;
    }

    public void setENTRAR2(JLabel ENTRAR2) {
        this.ENTRAR2 = ENTRAR2;
    }

    public JPanel getExitBtn() {
        return ExitBtn;
    }

    public void setExitBtn(JPanel ExitBtn) {
        this.ExitBtn = ExitBtn;
    }

    public JLabel getExitTxt() {
        return ExitTxt;
    }

    public void setExitTxt(JLabel ExitTxt) {
        this.ExitTxt = ExitTxt;
    }

    public JLabel getLOGOURBAN() {
        return LOGOURBAN;
    }

    public void setLOGOURBAN(JLabel LOGOURBAN) {
        this.LOGOURBAN = LOGOURBAN;
    }

    public JPanel getPANELENTRAR() {
        return PANELENTRAR;
    }

    public void setPANELENTRAR(JPanel PANELENTRAR) {
        this.PANELENTRAR = PANELENTRAR;
    }

    public JPanel getPANELENTRAR1() {
        return PANELENTRAR1;
    }

    public void setPANELENTRAR1(JPanel PANELENTRAR1) {
        this.PANELENTRAR1 = PANELENTRAR1;
    }

    public JPanel getPANELENTRAR2() {
        return PANELENTRAR2;
    }

    public void setPANELENTRAR2(JPanel PANELENTRAR2) {
        this.PANELENTRAR2 = PANELENTRAR2;
    }

    public JFrame getjFrame1() {
        return jFrame1;
    }

    public void setjFrame1(JFrame jFrame1) {
        this.jFrame1 = jFrame1;
    }

    public JLabel getjLabel1() {
        return jLabel1;
    }

    public void setjLabel1(JLabel jLabel1) {
        this.jLabel1 = jLabel1;
    }
   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        ExitBtn = new javax.swing.JPanel();
        ExitTxt = new javax.swing.JLabel();
        PANELENTRAR1 = new javax.swing.JPanel();
        ENTRAR1 = new javax.swing.JLabel();
        PANELENTRAR2 = new javax.swing.JPanel();
        ENTRAR2 = new javax.swing.JLabel();
        PANELENTRAR = new javax.swing.JPanel();
        ENTRAR = new javax.swing.JLabel();
        LOGOURBAN = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ExitTxt.setFont(new java.awt.Font("Segoe UI Historic", 0, 24)); // NOI18N
        ExitTxt.setText("   X");
        ExitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ExitTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout ExitBtnLayout = new javax.swing.GroupLayout(ExitBtn);
        ExitBtn.setLayout(ExitBtnLayout);
        ExitBtnLayout.setHorizontalGroup(
            ExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ExitTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        ExitBtnLayout.setVerticalGroup(
            ExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ExitBtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ExitTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(12, 12, 12))
        );

        PANELENTRAR1.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR1.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRAR1MouseExited(evt);
            }
        });

        ENTRAR1.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR1.setText("ATENCION AL CLIENTE");
        ENTRAR1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRAR1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRAR1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRAR1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRAR1Layout = new javax.swing.GroupLayout(PANELENTRAR1);
        PANELENTRAR1.setLayout(PANELENTRAR1Layout);
        PANELENTRAR1Layout.setHorizontalGroup(
            PANELENTRAR1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PANELENTRAR1Layout.setVerticalGroup(
            PANELENTRAR1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRAR1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        PANELENTRAR2.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR2.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRAR2MouseExited(evt);
            }
        });

        ENTRAR2.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR2.setText("     MIS DATOS");
        ENTRAR2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRAR2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRAR2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRAR2MouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRAR2Layout = new javax.swing.GroupLayout(PANELENTRAR2);
        PANELENTRAR2.setLayout(PANELENTRAR2Layout);
        PANELENTRAR2Layout.setHorizontalGroup(
            PANELENTRAR2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
        );
        PANELENTRAR2Layout.setVerticalGroup(
            PANELENTRAR2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRAR2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        PANELENTRAR.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRARMouseExited(evt);
            }
        });

        ENTRAR.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR.setText("CONSULTAR ENCARGOS");
        ENTRAR.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRARMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRARMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRARMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRARLayout = new javax.swing.GroupLayout(PANELENTRAR);
        PANELENTRAR.setLayout(PANELENTRARLayout);
        PANELENTRARLayout.setHorizontalGroup(
            PANELENTRARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PANELENTRARLayout.setVerticalGroup(
            PANELENTRARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRARLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        LOGOURBAN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LOGO (1).jpeg"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 2, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("EMPLEADO");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(ExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 181, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(PANELENTRAR, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(PANELENTRAR1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(PANELENTRAR2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(LOGOURBAN, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(229, 229, 229))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(16, 16, 16)
                .addComponent(LOGOURBAN)
                .addGap(32, 32, 32)
                .addComponent(PANELENTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PANELENTRAR2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(PANELENTRAR1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(ExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ExitTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitTxtMouseClicked
        this.dispose();
        javax.swing.JOptionPane.showMessageDialog(null, "Cerrando sesión...");
        login1.setVisible(true);
        
    }//GEN-LAST:event_ExitTxtMouseClicked

    private void ExitTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitTxtMouseEntered
        ExitBtn.setBackground(Color.red);
        ExitTxt.setForeground(Color.WHITE);
    }//GEN-LAST:event_ExitTxtMouseEntered

    private void ExitTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitTxtMouseExited
        ExitBtn.setBackground(Color.WHITE);
        ExitTxt.setForeground(Color.black);
    }//GEN-LAST:event_ExitTxtMouseExited

    private void ENTRAR1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR1MouseClicked
        enviarChatAdmin();
        enviarChatAdmin2();
    }//GEN-LAST:event_ENTRAR1MouseClicked

    private void ENTRAR1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR1MouseEntered
        PANELENTRAR1.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRAR1MouseEntered

    private void ENTRAR1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR1MouseExited
        PANELENTRAR1.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRAR1MouseExited

    private void PANELENTRAR1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRAR1MouseExited

    }//GEN-LAST:event_PANELENTRAR1MouseExited

    private void ENTRARMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRARMouseClicked
        ConsultarEncargosAdmin consultarEncargosAdmin = new ConsultarEncargosAdmin(encargoDAO, encargoJosephDAO, encargoNicolasDAO);
        consultarEncargosAdmin.setVisible(true);
    }//GEN-LAST:event_ENTRARMouseClicked

    private void ENTRARMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRARMouseEntered
        PANELENTRAR.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRARMouseEntered

    private void ENTRARMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRARMouseExited
        PANELENTRAR.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRARMouseExited

    private void PANELENTRARMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRARMouseExited

    }//GEN-LAST:event_PANELENTRARMouseExited

    private void PANELENTRAR2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRAR2MouseExited

    }//GEN-LAST:event_PANELENTRAR2MouseExited

    private void ENTRAR2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR2MouseExited
        PANELENTRAR2.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRAR2MouseExited

    private void ENTRAR2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR2MouseEntered
        PANELENTRAR2.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRAR2MouseEntered

    private void ENTRAR2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR2MouseClicked
        misDatosInterfaz.setVisible(true);
    }//GEN-LAST:event_ENTRAR2MouseClicked



    class FondoPanel extends JPanel {

        private Image imagen;

        @Override
        public void paint(Graphics g) {
            imagen = new ImageIcon(getClass().getResource("/Imagenes/fondo.jpg")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);

            setOpaque(false);

            super.paint(g);

        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ENTRAR;
    private javax.swing.JLabel ENTRAR1;
    private javax.swing.JLabel ENTRAR2;
    private javax.swing.JPanel ExitBtn;
    private javax.swing.JLabel ExitTxt;
    private javax.swing.JLabel LOGOURBAN;
    private javax.swing.JPanel PANELENTRAR;
    private javax.swing.JPanel PANELENTRAR1;
    private javax.swing.JPanel PANELENTRAR2;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
    
    

    public void enviarChatAdmin2(){
        
        if (respuestaChat2==null){
            boolChatRespuesta2=false;
        }
        
        if (interfazCliente2.boolChat2 == true&&boolChatRespuesta2==false) {
            respuestaChat2 = JOptionPane.showInputDialog(this, "USUARIO: NICOLAS CASTELLANOS \nSOLICITUD #"+interfazCliente2.randomNumber2+":\n\n"+'"'+interfazCliente2.solicitudChat2+'"'+"."+"\n\n");
            boolChatRespuesta2=true;
        }else JOptionPane.showMessageDialog(null, "TU CLIENTE (NICOLAS CASTELLANOS) NO PRESENTA NINGUNA SOLIITUD");
            

            
        interfazCliente2.recibirChatAdmin2(boolChatRespuesta2, respuestaChat2);
    }
    
        public void enviarChatAdmin(){
        
        if (respuestaChat==null){
            boolChatRespuesta=false;
        }
        
        if (interfazCliente.boolChat == true&&boolChatRespuesta==false) {
            respuestaChat = JOptionPane.showInputDialog(this, "USUARIO: JOSEPH REYES\nSOLICITUD #"+interfazCliente.randomNumber+":\n\n"+'"'+interfazCliente.solicitudChat+'"'+"."+"\n\n");
            boolChatRespuesta=true;
        }else JOptionPane.showMessageDialog(null, "TU CLIENTE (JOSEPH REYES) NO PRESENTA NINGUNA SOLIITUD");
            

            
        interfazCliente.recibirChatAdmin(boolChatRespuesta, respuestaChat);
    }
    
    public void recibirChatCliente(boolean boolChat, String solicitudChat, int randomNumber, String nombreCliente){

    }
    public void recibirChatCliente2(boolean boolChat2, String solicitudChat2, int randomNumber2, String nombreCliente2){

    }
}

