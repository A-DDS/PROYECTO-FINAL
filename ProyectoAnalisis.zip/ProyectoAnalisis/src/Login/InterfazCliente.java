package Login;

import Login.Login1;
import SourceAdmin.MisDatosInterfaz;
import SourceCliente.ConsultarPedidoCliente;
import SourceCliente.HacerPedidoCliente;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.util.Random;
import javax.swing.JLabel;

public class InterfazCliente extends javax.swing.JFrame {

    InterfazCliente.FondoPanel fondo = new InterfazCliente.FondoPanel();
    SourceCliente.MisDatosInterfaz misDatosInterfaz;
    Login1 login1;
    InterfazAdmin interfazAdmin;
    HacerPedidoCliente hacerPedidoCliente;
    ConsultarPedidoCliente consultarPedidoCliente;
    boolean boolChat = false;
    boolean intentoNuevo = false;
    String solicitudChat = null;
    String comprobacionIntento = null;
    Random rand = new Random();
    int randomNumber;

    public InterfazCliente(Login1 login1) {
        this.setContentPane(fondo);
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        misDatosInterfaz = new SourceCliente.MisDatosInterfaz();
        hacerPedidoCliente = new HacerPedidoCliente();
        consultarPedidoCliente = new ConsultarPedidoCliente();
        this.login1 = login1;
        randomNumber = rand.nextInt(10000);
    }

    public FondoPanel getFondo() {
        return fondo;
    }

    public void setFondo(FondoPanel fondo) {
        this.fondo = fondo;
    }

    public Login1 getLogin1() {
        return login1;
    }

    public void setLogin1(Login1 login1) {
        this.login1 = login1;
    }

    public InterfazAdmin getInterfazAdmin() {
        return interfazAdmin;
    }

    public void setInterfazAdmin(InterfazAdmin interfazAdmin) {
        this.interfazAdmin = interfazAdmin;
    }

    public JLabel getENTRAR() {
        return ENTRAR;
    }

    public void setENTRAR(JLabel ENTRAR) {
        this.ENTRAR = ENTRAR;
    }

    public JLabel getENTRAR1() {
        return ENTRAR1;
    }

    public void setENTRAR1(JLabel ENTRAR1) {
        this.ENTRAR1 = ENTRAR1;
    }

    public JLabel getENTRAR2() {
        return ENTRAR2;
    }

    public void setENTRAR2(JLabel ENTRAR2) {
        this.ENTRAR2 = ENTRAR2;
    }

    public JLabel getENTRAR4() {
        return ENTRAR4;
    }

    public void setENTRAR4(JLabel ENTRAR4) {
        this.ENTRAR4 = ENTRAR4;
    }

    public JPanel getExitBtn() {
        return ExitBtn;
    }

    public void setExitBtn(JPanel ExitBtn) {
        this.ExitBtn = ExitBtn;
    }

    public JLabel getExitTxt() {
        return ExitTxt;
    }

    public void setExitTxt(JLabel ExitTxt) {
        this.ExitTxt = ExitTxt;
    }

    public JLabel getLOGOURBAN() {
        return LOGOURBAN;
    }

    public void setLOGOURBAN(JLabel LOGOURBAN) {
        this.LOGOURBAN = LOGOURBAN;
    }

    public JPanel getPANELENTRAR() {
        return PANELENTRAR;
    }

    public void setPANELENTRAR(JPanel PANELENTRAR) {
        this.PANELENTRAR = PANELENTRAR;
    }

    public JPanel getPANELENTRAR1() {
        return PANELENTRAR1;
    }

    public void setPANELENTRAR1(JPanel PANELENTRAR1) {
        this.PANELENTRAR1 = PANELENTRAR1;
    }

    public JPanel getPANELENTRAR2() {
        return PANELENTRAR2;
    }

    public void setPANELENTRAR2(JPanel PANELENTRAR2) {
        this.PANELENTRAR2 = PANELENTRAR2;
    }

    public JPanel getPANELENTRAR4() {
        return PANELENTRAR4;
    }

    public void setPANELENTRAR4(JPanel PANELENTRAR4) {
        this.PANELENTRAR4 = PANELENTRAR4;
    }

    public JLabel getjLabel1() {
        return jLabel1;
    }

    public void setjLabel1(JLabel jLabel1) {
        this.jLabel1 = jLabel1;
    }

    public boolean isBoolChat() {
        return boolChat;
    }

    public void setBoolChat(boolean boolChat) {
        this.boolChat = boolChat;
    }

    public String getSolicitudChat() {
        return solicitudChat;
    }

    public void setSolicitudChat(String solicitudChat) {
        this.solicitudChat = solicitudChat;
    }

    public int getRandomNumber() {
        return randomNumber;
    }

    public void setRandomNumber(int randomNumber) {
        this.randomNumber = randomNumber;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        ExitBtn = new javax.swing.JPanel();
        ExitTxt = new javax.swing.JLabel();
        LOGOURBAN = new javax.swing.JLabel();
        PANELENTRAR = new javax.swing.JPanel();
        ENTRAR = new javax.swing.JLabel();
        PANELENTRAR1 = new javax.swing.JPanel();
        ENTRAR1 = new javax.swing.JLabel();
        PANELENTRAR2 = new javax.swing.JPanel();
        ENTRAR2 = new javax.swing.JLabel();
        PANELENTRAR4 = new javax.swing.JPanel();
        ENTRAR4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 2, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CLIENTE");

        ExitTxt.setFont(new java.awt.Font("Segoe UI Historic", 0, 24)); // NOI18N
        ExitTxt.setText("   X");
        ExitTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ExitTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ExitTxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ExitTxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ExitTxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout ExitBtnLayout = new javax.swing.GroupLayout(ExitBtn);
        ExitBtn.setLayout(ExitBtnLayout);
        ExitBtnLayout.setHorizontalGroup(
            ExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ExitBtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ExitTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        ExitBtnLayout.setVerticalGroup(
            ExitBtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ExitTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
        );

        LOGOURBAN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LOGO (1).jpeg"))); // NOI18N

        PANELENTRAR.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRARMouseExited(evt);
            }
        });

        ENTRAR.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR.setText(" CONSULTAR PEDIDO");
        ENTRAR.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRARMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRARMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRARMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRARLayout = new javax.swing.GroupLayout(PANELENTRAR);
        PANELENTRAR.setLayout(PANELENTRARLayout);
        PANELENTRARLayout.setHorizontalGroup(
            PANELENTRARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
        );
        PANELENTRARLayout.setVerticalGroup(
            PANELENTRARLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRARLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        PANELENTRAR1.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR1.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRAR1MouseExited(evt);
            }
        });

        ENTRAR1.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR1.setText("ATENCION AL CLIENTE");
        ENTRAR1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRAR1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRAR1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRAR1MouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRAR1Layout = new javax.swing.GroupLayout(PANELENTRAR1);
        PANELENTRAR1.setLayout(PANELENTRAR1Layout);
        PANELENTRAR1Layout.setHorizontalGroup(
            PANELENTRAR1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        PANELENTRAR1Layout.setVerticalGroup(
            PANELENTRAR1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRAR1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        PANELENTRAR2.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR2.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRAR2MouseExited(evt);
            }
        });

        ENTRAR2.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR2.setText("     MIS DATOS");
        ENTRAR2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRAR2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRAR2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRAR2MouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRAR2Layout = new javax.swing.GroupLayout(PANELENTRAR2);
        PANELENTRAR2.setLayout(PANELENTRAR2Layout);
        PANELENTRAR2Layout.setHorizontalGroup(
            PANELENTRAR2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
        );
        PANELENTRAR2Layout.setVerticalGroup(
            PANELENTRAR2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRAR2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        PANELENTRAR4.setBackground(new java.awt.Color(255, 153, 0));
        PANELENTRAR4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        PANELENTRAR4.setForeground(new java.awt.Color(204, 204, 204));
        PANELENTRAR4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PANELENTRAR4MouseExited(evt);
            }
        });

        ENTRAR4.setFont(new java.awt.Font("Monospaced", 3, 14)); // NOI18N
        ENTRAR4.setText("   HACER PEDIDO");
        ENTRAR4.setToolTipText("");
        ENTRAR4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ENTRAR4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        ENTRAR4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ENTRAR4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ENTRAR4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ENTRAR4MouseExited(evt);
            }
        });

        javax.swing.GroupLayout PANELENTRAR4Layout = new javax.swing.GroupLayout(PANELENTRAR4);
        PANELENTRAR4.setLayout(PANELENTRAR4Layout);
        PANELENTRAR4Layout.setHorizontalGroup(
            PANELENTRAR4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ENTRAR4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
        );
        PANELENTRAR4Layout.setVerticalGroup(
            PANELENTRAR4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PANELENTRAR4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ENTRAR4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(ExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(275, Short.MAX_VALUE)
                .addComponent(LOGOURBAN, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(262, 262, 262))
            .addGroup(layout.createSequentialGroup()
                .addGap(149, 149, 149)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PANELENTRAR2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(PANELENTRAR1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PANELENTRAR4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(PANELENTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(130, 130, 130))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(PANELENTRAR1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1))
                            .addComponent(ExitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addComponent(LOGOURBAN)
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(PANELENTRAR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(PANELENTRAR4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(PANELENTRAR2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(114, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ExitTxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitTxtMouseClicked

        javax.swing.JOptionPane.showMessageDialog(null, "Cerrando sesión...");
        login1.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ExitTxtMouseClicked

    private void ExitTxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitTxtMouseEntered
        ExitBtn.setBackground(Color.red);
        ExitTxt.setForeground(Color.WHITE);
    }//GEN-LAST:event_ExitTxtMouseEntered

    private void ExitTxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ExitTxtMouseExited
        ExitBtn.setBackground(Color.WHITE);
        ExitTxt.setForeground(Color.black);
    }//GEN-LAST:event_ExitTxtMouseExited

    private void PANELENTRARMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRARMouseExited

    }//GEN-LAST:event_PANELENTRARMouseExited

    private void PANELENTRAR1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRAR1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_PANELENTRAR1MouseExited

    private void PANELENTRAR2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRAR2MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_PANELENTRAR2MouseExited

    private void ENTRAR1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR1MouseExited
        PANELENTRAR1.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRAR1MouseExited

    private void ENTRAR1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR1MouseEntered
        PANELENTRAR1.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRAR1MouseEntered

    private void ENTRAR1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR1MouseClicked

        enviarChatCliente();
    }//GEN-LAST:event_ENTRAR1MouseClicked


    private void ENTRAR2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR2MouseExited
        PANELENTRAR2.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRAR2MouseExited

    private void ENTRAR2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR2MouseEntered
        PANELENTRAR2.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRAR2MouseEntered

    private void ENTRAR2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR2MouseClicked
        misDatosInterfaz.setVisible(true);
    }//GEN-LAST:event_ENTRAR2MouseClicked

    private void ENTRARMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRARMouseExited
        PANELENTRAR.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRARMouseExited

    private void ENTRARMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRARMouseEntered
        PANELENTRAR.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRARMouseEntered

    private void ENTRARMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRARMouseClicked

        String numerosimulado = JOptionPane.showInputDialog(this, "BIENVENIDO JOSEPH\nIngresa el numero de tu pedido:\n");

        try {
            int numeroPedido = Integer.parseInt(numerosimulado);

            if (numeroPedido == 1421) {
                consultarPedidoCliente.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "El numero de solicitud es erroneo");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor ingresa un número válido.");
        }

    }//GEN-LAST:event_ENTRARMouseClicked

    private void ENTRAR4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR4MouseClicked

        hacerPedidoCliente.setVisible(true);
    }//GEN-LAST:event_ENTRAR4MouseClicked

    private void ENTRAR4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR4MouseEntered
        PANELENTRAR4.setBackground(new Color(255, 204, 102));
    }//GEN-LAST:event_ENTRAR4MouseEntered

    private void ENTRAR4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ENTRAR4MouseExited
        PANELENTRAR4.setBackground(new Color(255, 153, 0));
    }//GEN-LAST:event_ENTRAR4MouseExited

    private void PANELENTRAR4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PANELENTRAR4MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_PANELENTRAR4MouseExited

    class FondoPanel extends JPanel {

        private Image imagen;

        @Override
        public void paint(Graphics g) {
            imagen = new ImageIcon(getClass().getResource("/Imagenes/fondo.jpg")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);

            setOpaque(false);

            super.paint(g);

        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ENTRAR;
    private javax.swing.JLabel ENTRAR1;
    private javax.swing.JLabel ENTRAR2;
    private javax.swing.JLabel ENTRAR4;
    private javax.swing.JPanel ExitBtn;
    private javax.swing.JLabel ExitTxt;
    private javax.swing.JLabel LOGOURBAN;
    private javax.swing.JPanel PANELENTRAR;
    private javax.swing.JPanel PANELENTRAR1;
    private javax.swing.JPanel PANELENTRAR2;
    private javax.swing.JPanel PANELENTRAR4;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
    public void enviarChatCliente() {

        if (interfazAdmin.boolChatRespuesta == true) {
            JOptionPane.showMessageDialog(null, "¡Tu solicitud ha sido respondida!\n\nSOLICITUD #" + randomNumber + ":\n" + '"' + solicitudChat + '"' + "\n\nRESPUESTA:\n" + '"' + interfazAdmin.respuestaChat + '"' + "\nCordialmente. TATIS");
            boolChat = false;
            interfazAdmin.boolChatRespuesta = false;
            intentoNuevo = true;

        }

        if (boolChat == false && interfazAdmin.boolChatRespuesta == false && intentoNuevo == false) {
            solicitudChat = JOptionPane.showInputDialog(this, "BIENVENIDO JOSEPH\n¿En que podemos colaborarte el dia de hoy?");
            if (solicitudChat != null) {
                boolChat = true;
                randomNumber = rand.nextInt(10000);
                interfazAdmin.recibirChatCliente(boolChat, solicitudChat, randomNumber);
                JOptionPane.showMessageDialog(null, "¡PERFECTO!\nUn asesor se encargara de tu solicitud en unos breves minutos...\n\nSOLICITUD #" + randomNumber + ":\n" + '"' + solicitudChat + '"');
            }

        } else if (boolChat == true && interfazAdmin.boolChatRespuesta == false) {
            JOptionPane.showMessageDialog(null, "Tu solicitud ya se encuentra en proceso, podrás generar una solicitud nuevamente cuando la actual sea resuelta.\n\nSOLICITUD #" + randomNumber + ":\n" + '"' + solicitudChat + '"');
        } else if (intentoNuevo == true) {
            intentoNuevo = false;
        }

    }

    public void recibirChatAdmin(boolean boolChatRespuesta, String respuestaChat) {

    }
}
