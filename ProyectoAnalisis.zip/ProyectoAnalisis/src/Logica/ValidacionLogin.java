
package Logica;

import javax.swing.JOptionPane;

public class ValidacionLogin {
    
    String useradmin1 = "tatis";
    private String passUseradmin1 = "tatiana";
    String userclient1 = "joseph";
    private String passUserclient1 = "reyes";

    
    public void usuarioValidacion(String usuario, String contraseña) {
        if (usuario.equals(useradmin1)){
            if (contraseña.equals(passUseradmin1)){
                javax.swing.JOptionPane.showMessageDialog(null, "Bienvenid@ " + useradmin1);
            }else javax.swing.JOptionPane.showMessageDialog(null, "Contraseña incorrecta");
        }else if (usuario.equals(userclient1)){
                    if (contraseña.equals(passUserclient1)){
                        javax.swing.JOptionPane.showMessageDialog(null, "Bienvenid@ " + userclient1);
                    }else javax.swing.JOptionPane.showMessageDialog(null, "Contraseña incorrecta");    
                }else javax.swing.JOptionPane.showMessageDialog(null, "Usuario inexistente");
    }    

    public String getUseradmin1() {
        return useradmin1;
    }

    public void setUseradmin1(String useradmin1) {
        this.useradmin1 = useradmin1;
    }

    public String getPassUseradmin1() {
        return passUseradmin1;
    }

    public void setPassUseradmin1(String passUseradmin1) {
        this.passUseradmin1 = passUseradmin1;
    }

    public String getUserclient1() {
        return userclient1;
    }

    public void setUserclient1(String userclient1) {
        this.userclient1 = userclient1;
    }

    public String getPassUserclient1() {
        return passUserclient1;
    }

    public void setPassUserclient1(String passUserclient1) {
        this.passUserclient1 = passUserclient1;
    }


    public ValidacionLogin() {
    }
}
