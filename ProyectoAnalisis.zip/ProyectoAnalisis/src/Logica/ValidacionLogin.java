
package Logica;

import javax.swing.JOptionPane;

public class ValidacionLogin {
    
    String useradmin1 = "tatiana";
    private String passUseradmin1 = "torres";
    String userclient1 = "joseph";
    private String passUserclient1 = "reyes";
    String userclient2 = "nicolas";
    private String passUserclient2 = "castellanos";

    public String getUserclient2() {
        return userclient2;
    }

    public void setUserclient2(String userclient2) {
        this.userclient2 = userclient2;
    }

    public String getPassUserclient2() {
        return passUserclient2;
    }

    public void setPassUserclient2(String passUserclient2) {
        this.passUserclient2 = passUserclient2;
    }


    
    public void usuarioValidacion(String usuario, String contraseña) {
        if (usuario.equals(useradmin1)){
            if (contraseña.equals(passUseradmin1)){
                javax.swing.JOptionPane.showMessageDialog(null, "Bienvenid@ " + useradmin1);
            }else javax.swing.JOptionPane.showMessageDialog(null, "Usuario inexistente o contraseña incorrecta");
        }else if (usuario.equals(userclient1)){
                    if (contraseña.equals(passUserclient1)){
                        javax.swing.JOptionPane.showMessageDialog(null, "Bienvenid@ " + userclient1);
                    }else javax.swing.JOptionPane.showMessageDialog(null, "Usuario inexistente o contraseña incorrecta");    
                }else if (usuario.equals(userclient2)){
                    if (contraseña.equals(passUserclient2)){
                        javax.swing.JOptionPane.showMessageDialog(null, "Bienvenid@ " + userclient2);
                    }else javax.swing.JOptionPane.showMessageDialog(null, "Usuario inexistente o contraseña incorrecta");    
                }else javax.swing.JOptionPane.showMessageDialog(null, "Usuario inexistente o contraseña incorrecta");
            
            
            
    }    

    public String getUseradmin1() {
        return useradmin1;
    }

    public void setUseradmin1(String useradmin1) {
        this.useradmin1 = useradmin1;
    }

    public String getPassUseradmin1() {
        return passUseradmin1;
    }

    public void setPassUseradmin1(String passUseradmin1) {
        this.passUseradmin1 = passUseradmin1;
    }

    public String getUserclient1() {
        return userclient1;
    }

    public void setUserclient1(String userclient1) {
        this.userclient1 = userclient1;
    }

    public String getPassUserclient1() {
        return passUserclient1;
    }

    public void setPassUserclient1(String passUserclient1) {
        this.passUserclient1 = passUserclient1;
    }


    public ValidacionLogin() {
    }
}
