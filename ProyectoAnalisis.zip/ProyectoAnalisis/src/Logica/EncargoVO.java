
package Logica;

public class EncargoVO {
    
    private String nombreCliente, lugarCarga, lugarDestino, ConductorCliente;

    public EncargoVO(String nombreCliente, String lugarCarga, String lugarDestino, String ConductorCliente, int codigoEncargo, int telefonoCliente) {
        this.nombreCliente = nombreCliente;
        this.lugarCarga = lugarCarga;
        this.lugarDestino = lugarDestino;
        this.ConductorCliente = ConductorCliente;
        this.codigoEncargo = codigoEncargo;
        this.telefonoCliente = telefonoCliente;
    }

    public String getConductorCliente() {
        return ConductorCliente;
    }

    public void setConductorCliente(String ConductorCliente) {
        this.ConductorCliente = ConductorCliente;
    }
    private int codigoEncargo, telefonoCliente;


    
    public EncargoVO(){
        
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getLugarCarga() {
        return lugarCarga;
    }

    public void setLugarCarga(String lugarCarga) {
        this.lugarCarga = lugarCarga;
    }

    public String getLugarDestino() {
        return lugarDestino;
    }

    public void setLugarDestino(String lugarDestino) {
        this.lugarDestino = lugarDestino;
    }

    public int getCodigoEncargo() {
        return codigoEncargo;
    }
    public int getCodigoEncargoJoseph() {
        return codigoEncargo;
    }
    
    public int getCodigoEncargoNicolas() {
        return codigoEncargo;
    }

    public void setCodigoEncargo(int codigoEncargo) {
        this.codigoEncargo = codigoEncargo;
    }
    

    public int getTelefonoCliente() {
        return telefonoCliente;
    }

    public void setTelefonoCliente(int telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }
        


}
