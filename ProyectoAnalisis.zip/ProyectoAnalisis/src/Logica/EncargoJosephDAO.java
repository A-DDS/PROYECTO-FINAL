/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import java.util.HashMap;
import javax.swing.JOptionPane;

/**
 *
 * @author josep
 */
public class EncargoJosephDAO {
    private EncargoNicolasDAO encargoNicolasDAO;
    private HashMap<Integer, EncargoVO> infoEncargosJoseph;

    public HashMap<Integer, EncargoVO> getInfoEncargosJoseph() {
        return infoEncargosJoseph;
    }

    public void setInfoEncargosJoseph(HashMap<Integer, EncargoVO> infoEncargosJoseph)
    {
        this.infoEncargosJoseph = infoEncargosJoseph;
    }

    public EncargoJosephDAO(HashMap<Integer, EncargoVO> infoEncargosJoseph) {
        this.infoEncargosJoseph = infoEncargosJoseph;
    }

    public EncargoJosephDAO() {
        this.infoEncargosJoseph = new HashMap<>();

    }

    public EncargoNicolasDAO getEncargoNicolasDAO() {
        return encargoNicolasDAO;
    }

    public void setEncargoNicolasDAO(EncargoNicolasDAO encargoNicolasDAO) {
        this.encargoNicolasDAO = encargoNicolasDAO;
    }

    public void crearEncargoJoseph(EncargoVO encargoVO) {
        if (infoEncargosJoseph.containsKey(encargoVO.getCodigoEncargoJoseph()) == false&&encargoNicolasDAO.getInfoEncargosNicolas().containsKey(encargoVO.getCodigoEncargoNicolas())==false) {
            infoEncargosJoseph.put(encargoVO.getCodigoEncargoJoseph(), encargoVO);
        }
    }
    public void eliminarEncargoJoseph(int codigo) {
        if (infoEncargosJoseph.containsKey(codigo) == true) {
            infoEncargosJoseph.remove(codigo);
        }
    }
}
