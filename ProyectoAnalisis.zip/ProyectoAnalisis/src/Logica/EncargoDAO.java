
package Logica;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import javax.swing.JOptionPane;

public class EncargoDAO {
    private HashMap<Integer, EncargoVO> infoEncargos;

    public HashMap<Integer, EncargoVO> getInfoEncargos() {
        return infoEncargos;
    }

    public void setInfoEncargos(HashMap<Integer, EncargoVO> infoEncargos)
    {
        this.infoEncargos = infoEncargos;
    }

    public EncargoDAO(HashMap<Integer, EncargoVO> infoEncargos) {
        this.infoEncargos = infoEncargos;
    }

    public EncargoDAO() {
        this.infoEncargos = new HashMap<>();
    }

    public void crearEncargo(EncargoVO encargoVO) {
        if (infoEncargos.containsKey(encargoVO.getCodigoEncargo()) == false) {
            infoEncargos.put(encargoVO.getCodigoEncargo(), encargoVO);
            JOptionPane.showMessageDialog(null, "ENCARGO REGISTRADO CORRECTAMENTE",
                    "Resgistrar", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO ya se encuentra registrado, ingrese uno diferente",
                    "ERROR", 0);
        }
    }

    public void eliminarEncargo(int codigo) {
        if (infoEncargos.containsKey(codigo) == true) {
            infoEncargos.remove(codigo);
            JOptionPane.showMessageDialog(null, "Se elimino correctamente", "Eliminar Encargo.", 1);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO no se encuentra registrado, intentelo de nuevo.", "Eliminar Encargo", 0);
        }

    }
/*
    public void modificarEncargo(int codigo, EncargoDAO encargoDAO) {

        if (infoEncargos.containsKey(codigo) == true) {
            ModificarEncargo ventana = new ModificarEncargo(codigo, getInfoEncargos(), encargoDAO);
            ventana.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Este CODIGO no se encuentra registrado, intentelo de nuevo.",
                    "ERROR", 0);

        }
        
    }
    
    public void actualizarEncargo(EncargoVO encargoVO){
        infoEncargos.replace(encargoVO.getCodigoEncargo(), encargoVO);
        JOptionPane.showMessageDialog(null, "Se actualizo correctamente.", "Actualizar Docente", 1);
    }
*/       
}
