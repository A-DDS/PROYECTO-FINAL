
package Logica;

import java.util.HashMap;
import javax.swing.JOptionPane;

public class EncargoNicolasDAO {
    private EncargoJosephDAO encargoJosephDAO;
    private HashMap<Integer, EncargoVO> infoEncargosNicolas;
    
    public HashMap<Integer, EncargoVO> getInfoEncargosNicolas() {
        return infoEncargosNicolas;
    }

    public void setInfoEncargosNicolas(HashMap<Integer, EncargoVO> infoEncargosNicolas)
    {
        this.infoEncargosNicolas = infoEncargosNicolas;
    }

    public void setEncargoJosephDAO(EncargoJosephDAO encargoJosephDAO) {
        this.encargoJosephDAO = encargoJosephDAO;
    }

    public EncargoNicolasDAO(HashMap<Integer, EncargoVO> infoEncargosNicolas) {
        this.infoEncargosNicolas = infoEncargosNicolas;
    }

    public EncargoNicolasDAO() {
        this.infoEncargosNicolas = new HashMap<>();
       
    }

    public void crearEncargoNicolas(EncargoVO encargoVO) {
            if (infoEncargosNicolas.containsKey(encargoVO.getCodigoEncargoNicolas()) == false&&encargoJosephDAO.getInfoEncargosJoseph().containsKey(encargoVO.getCodigoEncargoJoseph())== false) {
                infoEncargosNicolas.put(encargoVO.getCodigoEncargoNicolas(), encargoVO);
            }
    }
    public void eliminarEncargoNicolas(int codigo) {
        if (infoEncargosNicolas.containsKey(codigo) == true) {
            infoEncargosNicolas.remove(codigo);
        } 
    }
}
